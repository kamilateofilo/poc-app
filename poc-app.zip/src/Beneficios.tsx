// Beneficios.tsx
import React from 'react';
import { View, Text } from 'react-native';

const Beneficios: React.FC = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Página Beneficios</Text>
    </View>
  );
};

export default Beneficios;
