// Home.tsx
import React from 'react';
import { View, Text } from 'react-native';

const PAIFAgenda: React.FC = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Página PAIF Agenda</Text>
    </View>
  );
};

export default PAIFAgenda;
