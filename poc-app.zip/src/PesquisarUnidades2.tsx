// Home.tsx
import React from 'react';
import { View, Text } from 'react-native';

const Unidades2: React.FC = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Página Unidades2</Text>
    </View>
  );
};

export default Unidades2;
