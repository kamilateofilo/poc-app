// Home.tsx
import React from 'react';
import { View, Text } from 'react-native';

const PesquisarUnidades: React.FC = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Página Pesquisar Unidades</Text>
    </View>
  );
};

export default PesquisarUnidades;
