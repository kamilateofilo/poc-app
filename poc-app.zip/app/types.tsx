
export type RootStackParamList = {
    InicioCida: undefined;
    Login: undefined;
    Home: undefined;
    Beneficios: undefined;
    IdentificacaoFamilia: undefined;
    Cadastro: undefined;
    PAIFAgenda: undefined;
    PesquisarUnidades: undefined;
    Unidades1: undefined;
    Unidades2: undefined; 
    Sobre: undefined;
  };
  