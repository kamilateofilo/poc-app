import React, { useMemo } from "react";
import { Text, StyleSheet, View, ImageSourcePropType } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

export type FamiliaType = {
  endereo?: string;
  mingcutedownFill?: ImageSourcePropType;

  /** Style props */
  propMarginTop?: number | string;
};

const getStyleValue = (key: string, value: string | number | undefined) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};

const Familia = ({ endereo, mingcutedownFill, propMarginTop }: FamiliaType) => {
  const familiaStyle = useMemo(() => {
    return {
      ...getStyleValue("marginTop", propMarginTop),
    };
  }, [propMarginTop]);

  return (
    <View style={[styles.familia, familiaStyle]}>
      <View style={styles.familiaInner}>
        <View style={[styles.frameParent, styles.frameParentFlexBox]}>
          <View style={styles.frameParentFlexBox}>
            <Text style={styles.endereo}>{endereo}</Text>
          </View>
          <Image
            style={styles.mingcutedownFillIcon}
            contentFit="cover"
            source={mingcutedownFill}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  frameParentFlexBox: {
    flexDirection: "row",
    alignItems: "center",
  },
  endereo: {
    fontSize: FontSize.head2_size,
    fontWeight: "700",
    fontFamily: FontFamily.head2,
    color: Color.black,
    textAlign: "center",
  },
  mingcutedownFillIcon: {
    width: 24,
    height: 24,
    overflow: "hidden",
  },
  frameParent: {
    flexWrap: "wrap",
    justifyContent: "space-between",
    width: 328,
    flexDirection: "row",
  },
  familiaInner: {
    justifyContent: "flex-end",
    alignItems: "center",
    width: 328,
  },
  familia: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    borderRadius: Border.br_xs,
    backgroundColor: Color.background,
    padding: Padding.p_3xs,
  },
});

export default Familia;
